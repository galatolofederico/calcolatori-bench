CE_HDPATH=hd.img
